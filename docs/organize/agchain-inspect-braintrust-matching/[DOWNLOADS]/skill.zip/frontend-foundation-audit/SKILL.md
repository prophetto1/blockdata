---
name: frontend-foundation-audit
description: audit a repo's frontend foundation when shell layout ownership, navigation rails, visual tokens, theme definitions, component contracts, page patterns, or state presentation are inconsistent or unclear. use when repo code exists and you need a detailed foundation audit report before writing a canonical contract doc. prefer repo code as the source of truth. use page captures, layout captures, playwright evidence, and token/theme files as supporting evidence. group conflicts into discussion-ready bundles with recommendations, instead of pretending the correct direction is already known.
---

# Frontend Foundation Audit

## Overview

Run a repo-first audit of the frontend foundation and produce a discussion-ready report.

This skill does **not** write the canonical foundation contract as its primary artifact. It first determines what the repo actually does, where the shell and token contracts are fragmented, which patterns compete with each other, and what should be discussed before standardization.

**Announce at start:** "I'm using the frontend-foundation-audit skill to map the repo's frontend foundation, group conflicts, and prepare a discussion-ready audit report."

## Required posture

- **Repo code is mandatory.** If there is no repo code, stop and say the audit cannot proceed.
- **Repo code is the source of truth.** Prefer code over docs when they conflict.
- **Captures support the audit, not replace it.** Use page captures, layout captures, or Playwright evidence to confirm runtime behavior, shell composition, and visible inconsistencies.
- **Do not jump straight to a canonical contract.** The primary output is the audit report.
- **Do not flatten disagreements prematurely.** When multiple plausible patterns exist, group them into a conflict bundle and recommend a direction, but leave the final choice for discussion.

## Inputs

### Required
- repo code, local or connector-backed

### Use when available
- token/theme files
- page captures or layout captures
- Playwright or screenshot evidence
- Google Drive folders that act as repo mirrors

### Ignore by default
- internal docs or stale design notes, unless the user explicitly asks to include them

## What to audit by default

Audit all of these areas unless the user explicitly narrows the scope:

1. shell layout ownership
2. navigation and rail structure
3. token and theme definitions
4. component contract fragmentation
5. page pattern inconsistency
6. loading, empty, error, success, and permission-state presentation
7. light and dark mode consistency
8. accessibility basics at the shell and shared-component layer

## Workflow

### 1. Establish the foundation surface

Start by locating the files that own the shared frontend substrate.

Identify:
- shell layout owners
- page frame owners
- route layout wrappers
- navigation and rail owners
- shared token/theme definitions
- shared UI primitives and shared composites
- the highest-reuse page shells and workspaces

Do not begin with feature-specific one-offs.

### 2. Build the evidence map

For each audited area, gather evidence from code first, then confirm with captures if available.

For every finding, record:
- owner file or files
- runtime surface or route
- whether it appears canonical, duplicated, or conflicting
- whether the behavior is visible in captures

When a Google Drive folder acts as repo code, treat that as repo input and audit it the same way.

### 3. Inventory each foundation layer

Build explicit inventories for:

#### Shell ownership inventory
- top-level shell regions
- header ownership
- left rail ownership
- secondary rail ownership, if any
- content-area framing
- modal, drawer, and sheet shell patterns
- shell state ownership and persistence rules

#### Navigation inventory
- primary navigation structure
- secondary navigation structure
- route-to-surface mapping
- breadcrumb and page-header patterns
- where create/detail/edit flows live

#### Token and theme inventory
- all theme and token definition locations
- semantic tokens versus raw values
- light-mode values
- dark-mode values
- status colors and feedback colors
- spacing, radius, typography, border, and shadow definitions when centrally controlled
- raw hex, ad hoc utility, or component-local values that bypass the token system

#### Component contract inventory
- primitives
- shared composites
- page-level scaffolds
- repeated one-off substitutes for the same purpose
- visible states and variants
- duplicate or near-duplicate components

#### Page pattern inventory
Gather recurring patterns such as:
- registry/list pages
- detail workspaces
- create wizards
- draft/edit pages
- settings pages
- table-plus-inspector pages
- tabbed workspaces
- empty-state-first pages

### 4. Detect conflict bundles

When two or more patterns compete for the same role, do **not** just list them separately. Group them.

A conflict bundle should include:
- the specific role under dispute
- every competing implementation
- where each lives
- what each pattern is trying to solve
- why the repo currently lacks a single clear contract
- which one is the strongest candidate to become canonical
- what decision the team needs to make

Typical conflict bundles:
- two page frames that both act like the shell-standard wrapper
- multiple token sources defining overlapping colors
- two different table shells used for the same page type
- multiple detail workspace layouts for the same class of screen
- rail/navigation structures that disagree about where actions or context belong

### 5. Recommend, but do not over-resolve

For each conflict bundle, recommend a direction.

Base recommendations on:
- ownership clarity
- reuse breadth
- consistency with the visible shell
- degree of centralization
- light/dark mode integrity
- ease of enforcing the pattern later
- fit for feature-level reuse

Do **not** pretend recommendation equals final resolution. The audit should set up a human discussion, not bypass it.

### 6. Produce the audit report

The report must be detailed, structured, and discussion-ready.

Use the output shape in [references/report-template.md](references/report-template.md).

## Decision rules

When choosing the strongest candidate pattern inside a conflict bundle, prefer:
1. the pattern that is most clearly foundation-owned
2. the pattern with the broadest legitimate reuse
3. the pattern with the fewest local overrides
4. the pattern that works coherently in both light and dark modes
5. the pattern that composes cleanly with the shell and navigation model
6. the pattern that is easiest to validate and enforce in later skills

Do not prefer a pattern merely because it is newer, larger, or visually louder.

## Red flags

Stop and tighten the audit if you catch any of these:
- treating docs as source of truth over code
- calling something canonical because it looks polished once
- collapsing multiple competing implementations into one summary line
- ignoring shell-state ownership because the UI "seems fine"
- listing token files without tracing raw-value bypasses
- reviewing feature pages without first understanding the shell and rails
- recommending a direction without showing the competing evidence

## Required output

Every run should produce a single audit report with these sections:
- repository and evidence scope
- shell ownership map
- navigation and rail structure map
- token and theme inventory
- component contract inventory
- page pattern inventory
- state-presentation inventory
- accessibility and mode-consistency notes
- conflict bundles
- recommended directions for discussion
- unresolved decisions
- suggested next artifact: canonical foundation contract

Use the detailed section format in [references/report-template.md](references/report-template.md).

## Related follow-up

This skill prepares the repo for a later skill that writes the canonical frontend foundation contract. The contract-writing step should consume this audit instead of rediscovering the same conflicts from scratch.

## Example prompts

- "Audit this repo for frontend foundation conflicts and group the competing shell, token, and page patterns for discussion."
- "Use repo code plus layout captures to produce a frontend foundation audit report for writing-system."
- "Review this repo's shell ownership, nav structure, token definitions, and shared component patterns, then recommend a canonical direction without writing the contract yet."
