# Frontend Foundation Audit Report Template

Use this as the output shape for the skill.

## 1. Repository and evidence scope
- repo or repo mirror reviewed
- captures reviewed
- token/theme files reviewed
- major directories inspected
- scope exclusions, if any

## 2. Shell ownership map
For each shell region:
- region name
- owner file(s)
- runtime role
- current state owner
- notes on clarity or ambiguity

## 3. Navigation and rail structure map
- primary navigation owner(s)
- secondary rail owner(s)
- route-to-surface mapping notes
- page header / breadcrumb conventions
- action-placement conventions

## 4. Token and theme inventory
Group by token family or source.
For each source:
- file or files
- semantic tokens present
- raw values present
- light/dark coverage
- drift or overlap notes

## 5. Component contract inventory
Group by component role.
For each role:
- canonical candidate(s)
- competing implementations
- owner files
- usage notes
- visible state coverage

## 6. Page pattern inventory
For each recurring page type:
- pattern name
- strongest example
- competing examples
- structure notes
- shell alignment notes

## 7. State-presentation inventory
Cover:
- loading states
- empty states
- error states
- success states
- permission / no-context states
- async / polling states

## 8. Accessibility and mode-consistency notes
Summarize cross-cutting issues at the foundation layer.

## 9. Conflict bundles
For each bundle:
- bundle name
- role under dispute
- competing implementations
- evidence
- why the repo currently lacks one contract
- recommended direction
- discussion questions to resolve

## 10. Recommended directions
Summarize the strongest recommendations across bundles.

## 11. Unresolved decisions
List the decisions that require discussion before writing a canonical contract.

## 12. Suggested next artifact
State that the next artifact should be the canonical frontend foundation contract, derived from this audit.
